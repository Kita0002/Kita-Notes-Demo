export interface Position {
  x: number;
  y: number;
}

export interface TextStyle {
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
}

export interface MindNode {
  id: string;
  text: string;
  parentId: string | null;
  children: string[];
  color?: string;
  backgroundColor?: string;
  textStyle?: TextStyle;
  collapsed?: boolean;
  position: Position;
}

export interface MindMap {
  nodes: Record<string, MindNode>;
  rootId: string;
}

export interface UndoRedoState {
  past: MindMap[];
  present: MindMap;
  future: MindMap[];
}