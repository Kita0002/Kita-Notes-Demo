import React from 'react';
import Canvas from './components/Canvas';
import Sidebar from './components/Sidebar';

function App() {
  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      <Sidebar />
      <main className="flex-1 relative">
        <Canvas />
      </main>
    </div>
  );
}

export default App;