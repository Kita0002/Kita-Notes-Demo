import React, { useRef, useEffect, useState } from 'react';
import { useStore } from '../store';
import Node from './Node';
import Toolbar from './Toolbar';
import ColorPicker from './ColorPicker';
import { Position } from '../types';
import html2canvas from 'html2canvas';

export default function Canvas() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { nodes, addNode, rootId, present, canvasColor } = useStore();
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState<Position>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [startPos, setStartPos] = useState<Position>({ x: 0, y: 0 });
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [showColorPicker, setShowColorPicker] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Delete' && selectedNodeId) {
        useStore.getState().deleteNode(selectedNodeId);
        setSelectedNodeId(null);
      } else if ((e.key === 'Tab' || e.key === 'Enter') && selectedNodeId) {
        e.preventDefault();
        const parentNode = nodes[selectedNodeId];
        const siblingCount = parentNode.children.length;
        const isEnter = e.key === 'Enter';
        
        addNode({
          text: 'New Node',
          parentId: isEnter ? selectedNodeId : parentNode.parentId,
          position: {
            x: parentNode.position.x + (isEnter ? 200 : 0),
            y: parentNode.position.y + (isEnter ? siblingCount * 60 : 60),
          },
        });
      } else if (e.ctrlKey && e.key === 'z') {
        e.preventDefault();
        useStore.getState().undo();
      } else if (e.ctrlKey && e.key === 'y') {
        e.preventDefault();
        useStore.getState().redo();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedNodeId, nodes, addNode]);

  const handleWheel = (e: React.WheelEvent) => {
    if (e.ctrlKey) {
      e.preventDefault();
      const delta = e.deltaY > 0 ? 0.9 : 1.1;
      setScale(prev => Math.min(Math.max(0.1, prev * delta), 4));
    } else {
      setPosition(prev => ({
        x: prev.x - e.deltaX,
        y: prev.y - e.deltaY,
      }));
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 1 || e.button === 0) {
      setIsDragging(true);
      setStartPos({ x: e.clientX - position.x, y: e.clientY - position.y });
      setSelectedNodeId(null);
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPosition({
        x: e.clientX - startPos.x,
        y: e.clientY - startPos.y,
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleAddRootNode = () => {
    if (!rootId) {
      addNode({
        text: 'Central Topic',
        parentId: null,
        position: { x: window.innerWidth / 2 - 100, y: window.innerHeight / 2 - 20 },
      });
    }
  };

  const handleExport = async () => {
    if (!containerRef.current) return;
    
    try {
      const canvas = await html2canvas(containerRef.current, {
        backgroundColor: canvasColor,
      });
      
      const link = document.createElement('a');
      link.download = 'mindmap.png';
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  const handleZoomIn = () => setScale(prev => Math.min(prev * 1.2, 4));
  const handleZoomOut = () => setScale(prev => Math.max(prev * 0.8, 0.1));

  return (
    <>
      <Toolbar
        onZoomIn={handleZoomIn}
        onZoomOut={handleZoomOut}
        onExport={handleExport}
        selectedNodeId={selectedNodeId}
        setShowColorPicker={setShowColorPicker}
      />

      {showColorPicker && (
        <ColorPicker
          selectedNodeId={selectedNodeId}
          onClose={() => setShowColorPicker(false)}
        />
      )}

      <div 
        ref={containerRef}
        className="relative w-full h-screen overflow-hidden transition-colors duration-300"
        style={{
          backgroundColor: canvasColor,
          backgroundImage: `radial-gradient(circle, ${
            canvasColor === '#ffffff' ? '#00000008' : '#ffffff08'
          } 1px, transparent 1px)`,
          backgroundSize: '24px 24px',
        }}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {!rootId && (
          <div className="absolute inset-0 flex items-center justify-center">
            <h1 className="text-4xl font-bold text-gray-400 dark:text-gray-600 transition-opacity duration-500">
              KitaNote
            </h1>
            <button
              onClick={handleAddRootNode}
              className="absolute flex items-center gap-2 px-6 py-3 text-white bg-blue-500 rounded-lg hover:bg-blue-600 transition-colors shadow-lg opacity-0 group-hover:opacity-100"
            >
              Create Mind Map
            </button>
          </div>
        )}

        <div
          style={{
            transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
            transformOrigin: '50% 50%',
          }}
          className="absolute inset-0"
        >
          {Object.values(present.nodes).map(node => (
            <React.Fragment key={node.id}>
              <Node
                node={node}
                scale={scale}
                isSelected={selectedNodeId === node.id}
                onSelect={setSelectedNodeId}
              />
              {node.children.map(childId => {
                const childNode = present.nodes[childId];
                if (!childNode || node.collapsed) return null;
                
                const startX = node.position.x + 100;
                const startY = node.position.y + 20;
                const endX = childNode.position.x;
                const endY = childNode.position.y + 20;
                const midX = (startX + endX) / 2;
                
                return (
                  <svg
                    key={`line-${childId}`}
                    className="absolute top-0 left-0 w-full h-full pointer-events-none"
                    style={{ transform: `scale(${1 / scale})` }}
                  >
                    <path
                      d={`M ${startX} ${startY} C ${midX} ${startY}, ${midX} ${endY}, ${endX} ${endY}`}
                      fill="none"
                      stroke={childNode.color || '#94a3b8'}
                      strokeWidth="2"
                    />
                  </svg>
                );
              })}
            </React.Fragment>
          ))}
        </div>
      </div>
    </>
  );
}