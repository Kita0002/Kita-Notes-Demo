import React, { useState, useRef, useEffect } from 'react';
import { useStore } from '../store';
import { MindNode } from '../types';
import { ChevronRight, ChevronDown, Bold, Italic, Underline } from 'lucide-react';

interface NodeProps {
  node: MindNode;
  scale: number;
  isSelected: boolean;
  onSelect: (id: string) => void;
}

export default function Node({ node, scale, isSelected, onSelect }: NodeProps) {
  const { updateNode, updateNodeStyle } = useStore();
  const [isEditing, setIsEditing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditing]);

  const handleDoubleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsEditing(true);
  };

  const handleBlur = () => {
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      setIsEditing(false);
    }
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateNode(node.id, { ...node, text: e.target.value });
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsDragging(true);
    setStartPos({
      x: e.clientX - node.position.x,
      y: e.clientY - node.position.y
    });
    onSelect(node.id);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      updateNode(node.id, {
        ...node,
        position: {
          x: e.clientX - startPos.x,
          y: e.clientY - startPos.y
        }
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const toggleStyle = (style: keyof NonNullable<MindNode['textStyle']>) => {
    updateNodeStyle(node.id, {
      textStyle: {
        ...node.textStyle,
        [style]: !node.textStyle?.[style]
      }
    });
  };

  return (
    <div
      className={`
        absolute flex items-center transition-transform
        ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}
      `}
      style={{
        left: node.position.x,
        top: node.position.y,
        transform: `scale(${1 / scale})`,
      }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      <div
        className={`
          relative group px-4 py-2 rounded-lg shadow-lg
          transition-all duration-200
          ${isSelected ? 'ring-2 ring-blue-500' : ''}
        `}
        style={{
          backgroundColor: node.backgroundColor || '#ffffff',
          color: node.color || '#000000',
        }}
        onDoubleClick={handleDoubleClick}
      >
        {isEditing ? (
          <input
            ref={inputRef}
            type="text"
            value={node.text}
            onChange={handleTextChange}
            onBlur={handleBlur}
            onKeyDown={handleKeyDown}
            className="bg-transparent outline-none w-full min-w-[100px]"
            style={{
              fontWeight: node.textStyle?.bold ? 'bold' : 'normal',
              fontStyle: node.textStyle?.italic ? 'italic' : 'normal',
              textDecoration: node.textStyle?.underline ? 'underline' : 'none',
            }}
          />
        ) : (
          <span
            className="whitespace-nowrap"
            style={{
              fontWeight: node.textStyle?.bold ? 'bold' : 'normal',
              fontStyle: node.textStyle?.italic ? 'italic' : 'normal',
              textDecoration: node.textStyle?.underline ? 'underline' : 'none',
            }}
          >
            {node.text}
          </span>
        )}

        {isSelected && (
          <div className="absolute -top-10 left-1/2 -translate-x-1/2 flex items-center gap-1 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-1">
            <button
              onClick={() => toggleStyle('bold')}
              className={`p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700 ${
                node.textStyle?.bold ? 'bg-gray-200 dark:bg-gray-600' : ''
              }`}
            >
              <Bold size={14} />
            </button>
            <button
              onClick={() => toggleStyle('italic')}
              className={`p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700 ${
                node.textStyle?.italic ? 'bg-gray-200 dark:bg-gray-600' : ''
              }`}
            >
              <Italic size={14} />
            </button>
            <button
              onClick={() => toggleStyle('underline')}
              className={`p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700 ${
                node.textStyle?.underline ? 'bg-gray-200 dark:bg-gray-600' : ''
              }`}
            >
              <Underline size={14} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}