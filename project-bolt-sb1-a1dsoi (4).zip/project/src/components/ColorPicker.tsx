import React from 'react';
import { useStore } from '../store';
import { X } from 'lucide-react';

interface ColorPickerProps {
  selectedNodeId: string | null;
  onClose: () => void;
}

const colors = [
  '#ef4444', '#f97316', '#f59e0b', '#84cc16',
  '#22c55e', '#14b8a6', '#0ea5e9', '#6366f1',
  '#8b5cf6', '#d946ef', '#ec4899', '#000000'
];

const backgroundColors = [
  '#ffffff', '#f8fafc', '#fef2f2', '#fff7ed',
  '#fefce8', '#f7fee7', '#f0fdf4', '#f0fdfa',
  '#f0f9ff', '#eef2ff', '#faf5ff', '#fdf4ff'
];

export default function ColorPicker({ selectedNodeId, onClose }: ColorPickerProps) {
  const { updateNodeStyle, setCanvasColor, canvasColor } = useStore();

  const handleColorChange = (color: string) => {
    if (selectedNodeId) {
      updateNodeStyle(selectedNodeId, { color });
    }
  };

  const handleBackgroundChange = (backgroundColor: string) => {
    if (selectedNodeId) {
      updateNodeStyle(selectedNodeId, { backgroundColor });
    } else {
      setCanvasColor(backgroundColor);
    }
  };

  return (
    <div className="fixed right-4 top-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 z-50">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">
          {selectedNodeId ? 'Node Colors' : 'Canvas Color'}
        </h3>
        <button
          onClick={onClose}
          className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
        >
          <X size={20} />
        </button>
      </div>

      {selectedNodeId && (
        <>
          <div className="mb-4">
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">Text Color</p>
            <div className="grid grid-cols-6 gap-2">
              {colors.map(color => (
                <button
                  key={color}
                  className="w-8 h-8 rounded-full border-2 border-gray-200 dark:border-gray-700"
                  style={{ backgroundColor: color }}
                  onClick={() => handleColorChange(color)}
                />
              ))}
            </div>
          </div>

          <div className="mb-4">
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">Background Color</p>
            <div className="grid grid-cols-6 gap-2">
              {backgroundColors.map(color => (
                <button
                  key={color}
                  className="w-8 h-8 rounded-full border-2 border-gray-200 dark:border-gray-700"
                  style={{ backgroundColor: color }}
                  onClick={() => handleBackgroundChange(color)}
                />
              ))}
            </div>
          </div>
        </>
      )}

      {!selectedNodeId && (
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">Canvas Color</p>
          <div className="grid grid-cols-6 gap-2">
            {backgroundColors.map(color => (
              <button
                key={color}
                className={`w-8 h-8 rounded-full border-2 ${
                  color === canvasColor
                    ? 'border-blue-500'
                    : 'border-gray-200 dark:border-gray-700'
                }`}
                style={{ backgroundColor: color }}
                onClick={() => handleBackgroundChange(color)}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}