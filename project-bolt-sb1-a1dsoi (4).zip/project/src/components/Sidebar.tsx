import React from 'react';
import { useStore } from '../store';
import { Twitter } from 'lucide-react';

export default function Sidebar() {
  const { present } = useStore();

  return (
    <div className="w-64 h-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <h1 className="text-xl font-bold">KitaNote</h1>
      </div>

      <div className="flex-1 p-4">
        <h2 className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-2">
          Mind Maps
        </h2>
        <div className="space-y-2">
          {present.rootId && (
            <div className="p-2 rounded-lg bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300">
              {present.nodes[present.rootId]?.text || 'Untitled Map'}
            </div>
          )}
        </div>
      </div>

      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <a
          href="https://x.com/Kita0_"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
        >
          <Twitter size={20} />
          <span>Follow on X</span>
        </a>
      </div>
    </div>
  );
}