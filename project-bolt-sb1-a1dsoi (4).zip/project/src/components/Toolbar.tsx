import React from 'react';
import {
  Plus,
  ZoomIn,
  ZoomOut,
  Undo2,
  Redo2,
  Download,
  Trash2,
  Focus,
  Palette,
} from 'lucide-react';
import { useStore } from '../store';

interface ToolbarProps {
  onZoomIn: () => void;
  onZoomOut: () => void;
  onExport: () => void;
  selectedNodeId: string | null;
  setShowColorPicker: (show: boolean) => void;
}

export default function Toolbar({
  onZoomIn,
  onZoomOut,
  onExport,
  selectedNodeId,
  setShowColorPicker,
}: ToolbarProps) {
  const { addNode, deleteNode, undo, redo, centerView } = useStore();

  const handleAddNode = () => {
    addNode({
      text: 'New Node',
      parentId: selectedNodeId,
      position: { x: 200, y: 0 },
    });
  };

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-2 z-50">
      <button
        onClick={handleAddNode}
        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg tooltip"
        data-tooltip="Add Node (Tab)"
      >
        <Plus size={20} />
      </button>
      
      <button
        onClick={() => selectedNodeId && deleteNode(selectedNodeId)}
        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg tooltip"
        data-tooltip="Delete Node (Del)"
        disabled={!selectedNodeId}
      >
        <Trash2 size={20} />
      </button>

      <div className="w-px h-6 bg-gray-200 dark:bg-gray-700 mx-1" />

      <button
        onClick={onZoomIn}
        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg tooltip"
        data-tooltip="Zoom In"
      >
        <ZoomIn size={20} />
      </button>

      <button
        onClick={onZoomOut}
        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg tooltip"
        data-tooltip="Zoom Out"
      >
        <ZoomOut size={20} />
      </button>

      <button
        onClick={centerView}
        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg tooltip"
        data-tooltip="Center View"
      >
        <Focus size={20} />
      </button>

      <div className="w-px h-6 bg-gray-200 dark:bg-gray-700 mx-1" />

      <button
        onClick={undo}
        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg tooltip"
        data-tooltip="Undo (Ctrl+Z)"
      >
        <Undo2 size={20} />
      </button>

      <button
        onClick={redo}
        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg tooltip"
        data-tooltip="Redo (Ctrl+Y)"
      >
        <Redo2 size={20} />
      </button>

      <div className="w-px h-6 bg-gray-200 dark:bg-gray-700 mx-1" />

      <button
        onClick={() => setShowColorPicker(true)}
        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg tooltip"
        data-tooltip="Change Colors"
      >
        <Palette size={20} />
      </button>

      <button
        onClick={onExport}
        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg tooltip"
        data-tooltip="Export as PNG"
      >
        <Download size={20} />
      </button>
    </div>
  );
}