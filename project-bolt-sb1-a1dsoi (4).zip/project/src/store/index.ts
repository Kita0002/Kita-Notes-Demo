import { create } from 'zustand';
import { MindMap, MindNode, Position, UndoRedoState } from '../types';
import { nanoid } from 'nanoid';
import { persist } from 'zustand/middleware';

const MAX_HISTORY = 50;

interface MindMapStore extends UndoRedoState {
  canvasColor: string;
  addNode: (params: { text: string; parentId: string | null; position: Position }) => void;
  updateNode: (id: string, node: MindNode) => void;
  deleteNode: (id: string) => void;
  toggleCollapse: (id: string) => void;
  updateNodeStyle: (id: string, updates: Partial<MindNode>) => void;
  setCanvasColor: (color: string) => void;
  undo: () => void;
  redo: () => void;
  centerView: () => void;
}

const initialState: MindMap = {
  nodes: {},
  rootId: '',
};

export const useStore = create<MindMapStore>()(
  persist(
    (set, get) => ({
      past: [],
      present: initialState,
      future: [],
      canvasColor: '#f8fafc',

      addToHistory: (newPresent: MindMap) => {
        set(state => ({
          past: [...state.past.slice(-MAX_HISTORY), state.present],
          present: newPresent,
          future: [],
        }));
      },

      addNode: ({ text, parentId, position }) => {
        const id = nanoid();
        const { present } = get();
        
        const newNodes = { ...present.nodes };
        newNodes[id] = {
          id,
          text,
          parentId,
          children: [],
          position,
          color: '#3b82f6',
          backgroundColor: '#ffffff',
          textStyle: { bold: false, italic: false, underline: false },
          collapsed: false,
        };

        if (parentId && newNodes[parentId]) {
          newNodes[parentId] = {
            ...newNodes[parentId],
            children: [...newNodes[parentId].children, id],
          };
        }

        const newPresent = {
          nodes: newNodes,
          rootId: present.rootId || id,
        };

        get().addToHistory(newPresent);
      },

      updateNode: (id, node) => {
        const { present } = get();
        const newPresent = {
          ...present,
          nodes: { ...present.nodes, [id]: node },
        };
        get().addToHistory(newPresent);
      },

      deleteNode: (id) => {
        const { present } = get();
        const newNodes = { ...present.nodes };
        const node = newNodes[id];
        
        if (!node) return;

        if (node.parentId && newNodes[node.parentId]) {
          newNodes[node.parentId] = {
            ...newNodes[node.parentId],
            children: newNodes[node.parentId].children.filter(childId => childId !== id),
          };
        }

        const deleteChildren = (nodeId: string) => {
          const node = newNodes[nodeId];
          if (!node) return;
          
          node.children.forEach(childId => {
            deleteChildren(childId);
            delete newNodes[childId];
          });
        };

        deleteChildren(id);
        delete newNodes[id];

        const newPresent = {
          nodes: newNodes,
          rootId: id === present.rootId ? '' : present.rootId,
        };

        get().addToHistory(newPresent);
      },

      toggleCollapse: (id) => {
        const { present } = get();
        const node = present.nodes[id];
        if (!node) return;

        const newNode = {
          ...node,
          collapsed: !node.collapsed,
        };

        get().updateNode(id, newNode);
      },

      updateNodeStyle: (id, updates) => {
        const { present } = get();
        const node = present.nodes[id];
        if (!node) return;

        const newNode = { ...node, ...updates };
        get().updateNode(id, newNode);
      },

      setCanvasColor: (color) => {
        set({ canvasColor: color });
      },

      undo: () => {
        set(state => {
          if (state.past.length === 0) return state;
          const newPresent = state.past[state.past.length - 1];
          return {
            past: state.past.slice(0, -1),
            present: newPresent,
            future: [state.present, ...state.future],
          };
        });
      },

      redo: () => {
        set(state => {
          if (state.future.length === 0) return state;
          const newPresent = state.future[0];
          return {
            past: [...state.past, state.present],
            present: newPresent,
            future: state.future.slice(1),
          };
        });
      },

      centerView: () => {
        // Implementation handled in Canvas component
      },
    }),
    {
      name: 'kitanote-storage',
      partialize: (state) => ({
        present: state.present,
        canvasColor: state.canvasColor,
      }),
    }
  )
);